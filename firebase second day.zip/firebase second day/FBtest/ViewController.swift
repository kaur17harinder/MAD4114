//
//  ViewController.swift
//  FBtest
//
//  Created by robin on 2018-07-19.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
    
    @IBOutlet weak var usename: UITextField!
    @IBOutlet weak var textArea: UITextView!
    @IBOutlet weak var textView: UITextField!
    // database variable
    var ref: DatabaseReference!
    override func viewDidLoad() {
        super.viewDidLoad()
      
       self.ref = Database.database().reference()
        watchForChanges()
    }

    func  watchForChanges()
    {
        self.ref.child("chats").observe(DataEventType.childAdded , with:{
            (snapshot) in
            //when you should do when something gets added
            let x = snapshot.value as! Dictionary<String,String>
            let u = x["username"]!
            let m = x["message"]!
           /* self.textArea.text.append("something happens\n")
            self.textArea.text.append(x)
            self.textArea.text.append("\n ")
 */
            self.textArea.text.append("\(u) says: \(m)")
            self.textArea.text.append("\n")

        })
        /*
        //do somethings when something changes
        self.ref.child("monday").observe(DataEventType.childChanged, with:{
            (snapshot) in
            //when you should do when something gets added
            let x = snapshot.value as! String
            self.textArea.text.append("something changes \n")
            self.textArea.text.append(x)
            self.textArea.text.append("\n ")
        })
        //do somethings when something deleted
        self.ref.child("monday").observe(DataEventType.childRemoved, with:{
            (snapshot) in
            //when you should do when something gets added
            let x = snapshot.value as! String
            self.textArea.text.append("something deleted \n")
            self.textArea.text.append(x)
            self.textArea.text.append("\n ")
        })
 */
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addToFB(_ sender: UIButton) {
      
        //let x = textView.text!
        //self.ref.child("monday").childByAutoId().setValue(x)
        let user = usename.text!
        let msg = textView.text!
        
        let x = ["username":user, "message":msg]
        
        self.ref.child("chats").childByAutoId().setValue(x);
        
        // ui nonsense - clear the textbox
        textView.text = ""

        
    }
    
}

