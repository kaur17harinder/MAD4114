//
//  ViewController.swift
//  FBtest
//
//  Created by robin on 2018-07-19.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {

    @IBOutlet weak var textview: UITextField!
    //variable for accessing database firebase
    var db : DatabaseReference!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
     
      //set up your FIREBASE VARIABLE
        self.db = Database.database().reference()
        /*
        //add something to the databse
        self.db.setValue(2345667788)
        
        //add some keys
        let x: [String:Any] = ["age":25, "color" : "blue"]
        self.db.setValue(x)
        
        //add a new node
        self.db.child("cars").setValue(55)
        self.db.child("cars").setValue(55)
        
        //add nodes inside another node
        let y:[String:Any] = ["name": "kadeem", "dept": "CPCT"]
        self.db.child("instructors").setValue(y)
        */
  /*
        //create a random id
        self.db.childByAutoId().setValue("helloworld")
        self.db.childByAutoId().setValue("flurry")
        self.db.childByAutoId().setValue("wrap")
 */
        
        //teell firebase you r interested in knowing
        //when things changes
        //added
        //deletd
        //updated
        watchForChanges()
        
        
    }
    func watchForChanges()
    {
        self.db.child("todos").observe(DataEventType.childAdded, with: {
            //do something
           /* (snapshot) in
            print("something changed in the database")
 */
            (snapshot) in
            print("something added")
            let x = snapshot.value
            print(x)
        })
    }

    @IBAction func addTaskPressed(_ sender: UIButton) {
        print("add button pressed")
        let x = textview.text!
        if(x.isEmpty == true)
        {
           return
        }
        self.db.child("todos").childByAutoId().setValue(x)
        textview.text = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

