//
//  ViewController.swift
//  WeatherAppPretty
//
//  Created by robin on 2018-07-15.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = "https://httpbin.org/get"
        
        Alamofire.request(url, method: .get, parameters: nil).responseJSON {
        
            response in
            if response.result.isSuccess {
                if let json = response.result.value {
                    print("Here's the json: \(json)")
                }
                else {
                    print("Error when getting JSON from the response")
                }
            }
            else {
                print("Error while fetching data from URL")
            }
        
        }
        
        

       
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

